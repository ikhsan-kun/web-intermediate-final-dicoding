<<<<<<< HEAD

export function generateSubscribeButtonTemplate() {
  return `
   
  `;
}
=======

export function generateSubscribeButtonTemplate() {
  return `
   
  `;
}
>>>>>>> 38efe639763bae5c8458a1fa80a0ed4a005b757e
